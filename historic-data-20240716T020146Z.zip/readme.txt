Arduino Cloud historic data

variables:
  - id: dd36b6fe-2679-4fba-9322-0ebca1cfa54e
    name: Gps
    thingName: iPhone Thing
from: 2024-07-15T02:01:45Z
to: 2024-07-16T23:59:59Z

Have fun! :)
